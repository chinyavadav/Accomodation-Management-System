<?php
    include("connection.php");
    $apartments=array();
    if(isset($_GET["accno"])){
        $accountno=mysqli_real_escape_string($conn,$_GET["accno"]);
        if(isset($_GET["landlord"])){
    	   $statement="SELECT * FROM tblapartments WHERE fldlandlord='$accountno'";
        }else{
            $statement="SELECT * FROM tblapartments WHERE fldstatus='Vacant' and fldlandlord!='$accountno'";
        }
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){          
            $apartments[]=$record;
        }
    }
    echo json_encode($apartments);   
?>