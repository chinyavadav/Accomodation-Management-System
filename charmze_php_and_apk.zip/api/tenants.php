<?php
    include("connection.php");
    $tenants=array();
    if(isset($_GET["acc"])){
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
    	$statement="SELECT * FROM tblapartment_tenants JOIN tblclients ON tblapartment_tenants.fldaccountno=tblclients.fldaccountno";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){
            $stat="SELECT * FROM tblapartments WHERE fldapartmentid='$record[fldapartmentid]' and fldlandlord='$accountno'";
            $qry=mysqli_query($conn,$stat) or die(mysqli_error($conn));
            $rex=mysqli_fetch_assoc($qry);
            if(mysqli_num_rows($qry)==1){
                $tenants[]=$record;        
            }
        }
    }
    echo json_encode($tenants);   
?>