<?php
    include("connection.php");
    $bookings=array();
    if(isset($_GET["acc"]) && isset($_GET["app"])){
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        $apartmentno=mysqli_real_escape_string($conn,$_GET["app"]);
        $datetime=date('Y-m-d');
        $statement="INSERT INTO tblapartment_tenants VALUES('$apartmentno','$accountno','$datetime')";
        $query=mysqli_query($conn,$statement) or die(failed());
        $statement="DELETE FROM tblbookings WHERE fldapartmentid='$apartmentno' and fldaccountno='$accountno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));

        $bookings["response"]="success";
    }

    function failed(){
        $msg=Array("response"=>"failed");
        echo json_encode($msg);   
    }
    echo json_encode($bookings);   
?>