<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $apartmentid=mysqli_real_escape_string($conn,$request->apartmentid);
	        $accountno=mysqli_real_escape_string($conn,$request->accountno);
	        $comment=mysqli_real_escape_string($conn,$request->comment);
	        $datetime=date('Y-m-d H:i:s');

	        $statement="INSERT INTO tblbookings VALUES('$apartmentid','$accountno','$datetime','$comment','Pending')";
	        $query=mysqli_query($conn,$statement) or die(duplication());
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function duplication(){
		$response=array("response"=>"failed","error"=>"duplication");
		echo json_encode($response);
	}

?>