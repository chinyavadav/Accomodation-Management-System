<?php
	include("connection.php");
    if(isset($_GET["accountno"])){
        $messages=array();
        $array=array();
        $accountno=mysqli_real_escape_string($conn,$_GET["accountno"]);
        $statement="SELECT * FROM tblchats WHERE fldfrom='$accountno' or fldto='$accountno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        
        while($record=mysqli_fetch_assoc($query)){
            $temp=array();
            $temp["messageId"]=$record["fldmessageid"];
            $temp["userId"]=$record["fldfrom"];
            $temp["toUserId"]=$record["fldto"];            
            $temp["time"]=$record["fldtimestamp"];
            $temp["message"]=$record["fldmessage"];
            $temp["status"]="success";

            $statement="SELECT * FROM tblclients WHERE fldaccountno='$record[fldto]' or fldaccountno='$record[fldfrom]'";
            $client_query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($client=mysqli_fetch_assoc($client_query)){
                if($client["fldaccountno"]==$record["fldto"]){
                    $temp["userFullName"]=$client['fldfirstname'].' '.$client['fldsurname'];
                }elseif($client["fldaccountno"]==$record["fldfrom"]){
                    $temp["touserFullName"]=$client['fldfirstname'].' '.$client['fldsurname'];
                }
            }
            $array[]=$temp;
        }
        $messages["array"]=$array;
        echo json_encode($messages);
    }
?>