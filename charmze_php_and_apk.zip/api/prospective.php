<?php
    include("connection.php");
    $bookings=array();
    if(isset($_GET["acc"])){
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        if(isset($_GET["app"])){
            $apartmentno=mysqli_real_escape_string($conn,$_GET["app"]);
            if(isset($_GET["decline"])){
                $statement="UPDATE tblbookings SET fldstatus='Declined' WHERE fldapartmentid='$apartmentno' and fldaccountno='$accountno'";
            }else if(isset($_GET["approve"])){
                $statement="UPDATE tblbookings SET fldstatus='Approved' WHERE fldapartmentid='$apartmentno' and fldaccountno='$accountno'";  
            }
            if(isset($statement)){
                $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
                $bookings["response"]="success";
            }else{
                $bookings["response"]="failed";
            }
        }else{
            $statement="SELECT tblbookings.fldaccountno,tblbookings.fldapartmentid,tblclients.fldfirstname,tblclients.fldsurname,tblbookings.fldstatus,tblclients.fldsex FROM tblbookings JOIN tblclients ON tblbookings.fldaccountno=tblclients.fldaccountno WHERE tblbookings.fldstatus!='Declined'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($record=mysqli_fetch_assoc($query)){ 
                $apartmentid=$record['fldapartmentid'];
                $stat="SELECT fldlandlord FROM tblapartments WHERE fldapartmentid='$apartmentid' LIMIT 0,1";
                $qry=mysqli_query($conn,$stat) or die(mysqli_error($conn));
                $rex=mysqli_fetch_assoc($qry);
                if($rex['fldlandlord']==$accountno){
                    $bookings[]=$record;
                }    
            }
        }
    }
    echo json_encode($bookings);   
?>