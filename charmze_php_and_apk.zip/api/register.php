<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents('php://input');
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $phoneno=mysqli_real_escape_string($conn,$request->phoneno);
	        $firstname=mysqli_real_escape_string($conn,$request->firstname);
	        $surname=mysqli_real_escape_string($conn,$request->surname);
	        $sex=mysqli_real_escape_string($conn,$request->sex);
	        $status='Active';	        
	        $password=mysqli_real_escape_string($conn,$request->password);
	        $date=date('Y-m-d');
	        $accountno=generateAccountNo();

        	$statement="INSERT INTO tblclients VALUES('$accountno','$phoneno','$firstname','$surname','$sex','$status',md5('$password'),'$date')";
        	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        	$response=array('response'=>'success');
		}else {
	        $response=array('response'=>'failed');
	    }
	    echo json_encode($response);	    
	}

	function generateAccountNo(){
		$alphabet=Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
		return "C".date('y').random_int(1000,9999).$alphabet[random_int(0,25)];
	}
?>