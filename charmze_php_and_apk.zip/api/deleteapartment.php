<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $apartmentid=mysqli_real_escape_string($conn,$request->apartmentid);
	        $statement="DELETE FROM tblapartments WHERE fldapartmentid='$apartmentid'";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	       	$statement="UPDATE tblbookings SET fldstatus='Deleted' WHERE fldapartmentid='$apartmentid'";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

?>