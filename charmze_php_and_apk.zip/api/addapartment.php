<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $landlord=$request->landlord;
	        $slideOneForm=$request->slideOneForm;
	        $slideTwoForm=$request->slideTwoForm;

	        $apartmentid=generateApartmentID();
	        $address=mysqli_real_escape_string($conn,$slideOneForm->address);
	        $township=mysqli_real_escape_string($conn,$slideOneForm->township);
	        $district=mysqli_real_escape_string($conn,$slideOneForm->district);

			$apartmenttype=mysqli_real_escape_string($conn,$slideTwoForm->apartmenttype);
	        $rooms=mysqli_real_escape_string($conn,$slideTwoForm->rooms);
	        $bedrooms=mysqli_real_escape_string($conn,$slideTwoForm->bedrooms);
	        $bathrooms=mysqli_real_escape_string($conn,$slideTwoForm->bathrooms);
	        $kitchens=mysqli_real_escape_string($conn,$slideTwoForm->kitchens);
	        $lounges=mysqli_real_escape_string($conn,$slideTwoForm->lounges);
	        $costrange=mysqli_real_escape_string($conn,$slideTwoForm->costrange);
	        $comment=mysqli_real_escape_string($conn,$slideTwoForm->comment);
	        $datetime=date('Y-m-d H:i:s');

	        $statement="INSERT INTO tblapartments VALUES('$apartmentid','$landlord','$address','$township','$district','','','$apartmenttype','$rooms','$bedrooms','$bathrooms','$kitchens','$lounges','$comment','Vacant','$datetime','$costrange')";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success","apartmentid"=>$apartmentid);
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}

	function generateApartmentID(){
		$alphabet=Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
		return "A".date('y').random_int(1000,9999).$alphabet[random_int(0,25)];
	}
?>