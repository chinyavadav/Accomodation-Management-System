-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2019 at 01:49 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `charmze`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblapartments`
--

CREATE TABLE `tblapartments` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldlandlord` varchar(8) DEFAULT NULL,
  `fldaddress` varchar(200) DEFAULT NULL,
  `fldtownship` varchar(50) DEFAULT NULL,
  `flddistrict` varchar(50) DEFAULT NULL,
  `fldlat` varchar(20) DEFAULT NULL,
  `fldlng` varchar(20) DEFAULT NULL,
  `fldapartmenttype` varchar(20) DEFAULT NULL,
  `fldrooms` int(11) DEFAULT NULL,
  `fldbedrooms` int(11) DEFAULT NULL,
  `fldbathrooms` int(11) DEFAULT NULL,
  `fldkitchens` int(11) DEFAULT NULL,
  `fldlounges` int(11) NOT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcostrange` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblapartments`
--

INSERT INTO `tblapartments` (`fldapartmentid`, `fldlandlord`, `fldaddress`, `fldtownship`, `flddistrict`, `fldlat`, `fldlng`, `fldapartmenttype`, `fldrooms`, `fldbedrooms`, `fldbathrooms`, `fldkitchens`, `fldlounges`, `fldcomment`, `fldstatus`, `flddatetime`, `fldcostrange`) VALUES
('A193011U', 'C192345N', '4312 Nehanda Road', 'Adelaide Park', 'Gweru', '', '', 'Shared', 12, 4, 2, 2, 1, '', 'Vacant', '2019-05-15 12:30:46', '<$100'),
('A196556W', 'C195179V', '312 Nehosho Road', 'Nehosho', 'Gweru', '', '', 'Shared', 10, 2, 2, 1, 1, '', 'Vacant', '2019-05-15 12:36:00', '$100-$199'),
('A198832Q', 'C192345N', '4365 Mutage Street', 'Senga', 'Gweru', '', '', 'Full Rental', 5, 2, 1, 1, 1, '', 'Vacant', '2019-05-15 12:32:22', '$500-$999'),
('A199844O', 'C192345N', '56 Senga Road', 'Adelaide Park', 'Gweru', '', '', 'Shared', 12, 6, 2, 2, 1, '', 'Vacant', '2019-05-15 12:33:59', '$100-$199');

-- --------------------------------------------------------

--
-- Table structure for table `tblapartment_tenants`
--

CREATE TABLE `tblapartment_tenants` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldaccountno` varchar(8) NOT NULL,
  `flddatetime` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblapartment_tenants`
--

INSERT INTO `tblapartment_tenants` (`fldapartmentid`, `fldaccountno`, `flddatetime`) VALUES
('A196556W', 'C192345N', '2019-05-17');

-- --------------------------------------------------------

--
-- Table structure for table `tblbackups`
--

CREATE TABLE `tblbackups` (
  `fldbackupid` int(11) NOT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `flddoneby` varchar(64) DEFAULT NULL,
  `fldfilename` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbackups`
--

INSERT INTO `tblbackups` (`fldbackupid`, `flddatetime`, `flddoneby`, `fldfilename`) VALUES
(1, '2019-05-11 07:07:14', 'admin@charmze.co.zw', '1557551234.sql'),
(2, '2019-05-12 18:55:33', 'admin@charmze.co.zw', '1557680133.sql'),
(3, '2019-05-13 15:53:32', 'admin@charmze.co.zw', '1557755612.sql');

-- --------------------------------------------------------

--
-- Table structure for table `tblbookings`
--

CREATE TABLE `tblbookings` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldaccountno` varchar(8) NOT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblchats`
--

CREATE TABLE `tblchats` (
  `fldmessageid` int(11) NOT NULL,
  `fldfrom` varchar(8) DEFAULT NULL,
  `fldto` varchar(8) DEFAULT NULL,
  `fldmessage` varchar(1000) DEFAULT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblchats`
--

INSERT INTO `tblchats` (`fldmessageid`, `fldfrom`, `fldto`, `fldmessage`, `fldtimestamp`) VALUES
(1, 'C195179V', 'C192345N', 'Hie', '1557928627000'),
(2, 'C195179V', 'C192345N', 'Halo', '1557929339000'),
(3, 'C195179V', 'C192345N', 'halo', '1557929354000'),
(4, 'C192345N', 'C195179V', 'how are you', '1557931518000'),
(5, 'C195179V', 'C192345N', 'Ok', '1557932437000'),
(6, 'C192345N', 'C195179V', 'eg', '1557933331000'),
(7, 'C192345N', 'C195179V', '?', '1557933448000'),
(8, 'C195179V', 'C192345N', 'dfjhgjhgjfd', '1558013913000'),
(9, 'C195179V', 'C192345N', 'jsdfsdjfhvictor', '1558098728000'),
(10, 'C195179V', 'C192345N', 'ok', '1558098850000'),
(11, 'C195179V', 'C192345N', 'bg', '1558099009000'),
(12, 'C195179V', 'C192345N', 'Gghg', '1558102693000'),
(13, 'C192345N', 'C195179V', 'Ghhj', '1558451005000');

-- --------------------------------------------------------

--
-- Table structure for table `tblclients`
--

CREATE TABLE `tblclients` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldphoneno` varchar(10) NOT NULL,
  `fldfirstname` varchar(50) DEFAULT NULL,
  `fldsurname` varchar(30) DEFAULT NULL,
  `fldsex` varchar(10) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  `flddate` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclients`
--

INSERT INTO `tblclients` (`fldaccountno`, `fldphoneno`, `fldfirstname`, `fldsurname`, `fldsex`, `fldstatus`, `fldpassword`, `flddate`) VALUES
('C192345N', '0782135087', 'John', 'Moyo', 'Male', 'Active', '5f4dcc3b5aa765d61d8327deb882cf99', '2019-05-08'),
('C195179V', '0776467996', 'Chamunorwa', 'Musariri', 'Male', 'Active', '5f4dcc3b5aa765d61d8327deb882cf99', '2019-05-13'),
('C195875E', '0712923278', 'Amanda', 'Ndebele', 'Female', 'Active', '5f4dcc3b5aa765d61d8327deb882cf99', '2019-05-17');

-- --------------------------------------------------------

--
-- Table structure for table `tblprofiles`
--

CREATE TABLE `tblprofiles` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldmaritalstatus` varchar(20) DEFAULT NULL,
  `fldcohabitors` int(11) DEFAULT NULL,
  `fldother` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `fldemail` varchar(64) NOT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`fldemail`, `fldfirstname`, `fldlastname`, `fldpassword`) VALUES
('admin@charmze.co.zw', 'John', 'Moyo', '5f4dcc3b5aa765d61d8327deb882cf99'),
('sales@charmze.co.zw', 'Bill', 'Gates', '5f4dcc3b5aa765d61d8327deb882cf99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblapartments`
--
ALTER TABLE `tblapartments`
  ADD PRIMARY KEY (`fldapartmentid`);

--
-- Indexes for table `tblapartment_tenants`
--
ALTER TABLE `tblapartment_tenants`
  ADD PRIMARY KEY (`fldapartmentid`,`fldaccountno`);

--
-- Indexes for table `tblbackups`
--
ALTER TABLE `tblbackups`
  ADD PRIMARY KEY (`fldbackupid`);

--
-- Indexes for table `tblbookings`
--
ALTER TABLE `tblbookings`
  ADD PRIMARY KEY (`fldapartmentid`,`fldaccountno`);

--
-- Indexes for table `tblchats`
--
ALTER TABLE `tblchats`
  ADD PRIMARY KEY (`fldmessageid`);

--
-- Indexes for table `tblclients`
--
ALTER TABLE `tblclients`
  ADD PRIMARY KEY (`fldaccountno`),
  ADD UNIQUE KEY `fldphoneno` (`fldphoneno`);

--
-- Indexes for table `tblprofiles`
--
ALTER TABLE `tblprofiles`
  ADD PRIMARY KEY (`fldaccountno`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`fldemail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblbackups`
--
ALTER TABLE `tblbackups`
  MODIFY `fldbackupid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblchats`
--
ALTER TABLE `tblchats`
  MODIFY `fldmessageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
