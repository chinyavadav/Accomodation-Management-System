<?php
    include("session.php");include("../includes/connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        
        $nationalid=mysqli_real_escape_string($conn,$_POST['txtnationalid']);
        $bp=mysqli_real_escape_string($conn,$_POST['txtbloodpressure']);
        $weight=mysqli_real_escape_string($conn,$_POST['txtweight']);
        $sugarlevel=mysqli_real_escape_string($conn,$_POST['txtsugarlevel']);
        $parity=mysqli_real_escape_string($conn,$_POST['txtparity']);
        $currentmedication=mysqli_real_escape_string($conn,$_POST['txtcurrentmedication']);
        $method=mysqli_real_escape_string($conn,$_POST['cbomethod']);
        $datetime=date('Y-m-d H:i:s');

        $duration_statement=mysqli_query($conn,"SELECT * FROM tblmethods WHERE fldmethod_name='$method' LIMIT 0,1");
        $rec=mysqli_fetch_assoc($duration_statement);
        $cost=$rec['fldprice'];
        $durations=array("Months"=>30,"Days"=>1,"Years"=>365);
        $vector=preg_split('[\s]',$rec['fldduration']);
        $days=$vector[0]*$durations[$vector[1]];
        $nextdate=date('Y-m-d',$days*24*60*60+time());


        $statement="INSERT INTO tblservices VALUES('','$nationalid','$bp','$weight','$sugarlevel','$parity','$currentmedication','$method','$nextdate','$datetime')";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $getlastid=mysqli_query($conn,"SELECT LAST_INSERT_ID()") or die(mysqli_error($conn));
        $serviceid=mysqli_fetch_assoc($getlastid)["LAST_INSERT_ID()"];
        header("Location: payment.php?serviceid=".base64_encode($serviceid)."&natid=".base64_encode($nationalid)."&cost=".base64_encode($cost));
        exit;

    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CHARMZE Accomodation System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
    <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <div id="warpper">
        <?php include("header.html");?></nav>
        <div class="container">
            <h1><i class='fa fa-user'></i> Serve Client</h1>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Advanced Table
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>National ID</th>
                                        <th>Surname</th>
                                        <th>Name</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $query=mysqli_query($conn,"SELECT * FROM tblclients") or die(mysqli_error($conn));
                                        $index=0;
                                        $customers=[];
                                        while($result=mysqli_fetch_assoc($query)){
                                            //var_dump($result);
                                            echo "<tr>";
                                            echo "<td><a href='client.php?id=".base64_encode($result['fldnationalid'])."'>".$result['fldnationalid']."</a></td>";
                                            echo "<td>".$result['fldlastname']."</td>";
                                            echo "<td>".$result['fldfirstname']."</td>";
                                            echo  "<td><button onclick='serve($index)' data-toggle='modal' data-target='#myModal' class='btn btn-block btn-success'><i class='fa fa-check'></i> Select</button></td>";
                                            echo  "<td><button onclick='filter($index)' data-toggle='modal' data-target='#myModal1' class='btn btn-block btn-primary'><i class='fa fa-history'></i> Medical History</button></td>";
                                            echo "</tr>";                                            
                                            $customers[$index]=[$result['fldnationalid'],$result['fldfirstname'],$result['fldlastname']];
                                            $index++;
                                        }
                                    ?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"></h4>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="form-group col-lg-6">
                            <label>Blood Pressure (Diastolic/Systolic)</label>
                            <div class="input-group">
                                <input class="form-control" placeholder="Blood Pressure" name="txtbloodpressure" maxlength="20" type="text" pattern="[0-9]{2,3}\/{1}[0-9]{2,3}" required>
                                <input name="txtnationalid" type="hidden" id="natid">
                                <span class="input-group-addon">mmHg</span>
                            </div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label>Weight</label>
                            <div class="input-group">
                                <input class="form-control" placeholder="Blood Pressure" name="txtweight" maxlength="20" required type='number' min='0'>
                                <span class="input-group-addon">Kg</span>
                            </div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label>Sugar Level</label>
                            <div class="input-group">
                                <input class="form-control" placeholder="Sugar Level" name="txtsugarlevel" maxlength="20" required pattern="[\d]{2}[\.][\d]{1}">
                                <span class="input-group-addon">mmol/L</span>
                            </div>
                        </div>
                        <div class="form-group col-lg-6">
                            <label>Parity</label>
                            <div class="input-group">
                                <input class="form-control" placeholder="Number of Births" type="number" name="txtparity" min="0" max="20" pettern="[\d]" required>
                                <span class="input-group-addon">Births</span>
                            </div>
                        </div>
                        <div class="form-group col-lg-12">
                            <label>Current Medication</label>
                            <textarea class="form-control" placeholder="Current Medication" name="txtcurrentmedication" rows="2" maxlength="200">                                                
                            </textarea>
                        </div>
                        <div class="form-group col-lg-12">
                            <label>Prescibed Method</label>
                            <select name="cbomethod" class="form-control">
                                <?php
                                    $methods_statement=mysqli_query($conn,"SELECT * FROM tblmethods");
                                    while($method=mysqli_fetch_assoc($methods_statement)){
                                        echo "<option>$method[fldmethod_name]</option>";
                                    }
                                ?>
                            </select>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <div class="form-group col-lg-12">
                            <button class="btn btn-primary btn-block"><i class="fa fa-save"></i> Next</button>
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
     <!-- Modal -->
    <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel1"></h4>
                </div>
                <div class="modal-body">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-history">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>National ID</th>
                                <th>Method</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $query=mysqli_query($conn,"SELECT * FROM tblservices") or die(mysqli_error($conn));
                                while($result=mysqli_fetch_assoc($query)){
                                    //var_dump($result);
                                    echo "<tr>";
                                    echo "<td><a href='booking.php?id=".base64_encode($result['fldserviceid'])."'>".$result['fldserviceid']."</a></td>";
                                    echo "<td>".$result['fldnationalid']."</td>";
                                    echo "<td>".$result['fldmethod']."</td>";
                                    echo "<td>".$result['flddatetime']."</td>";
                                    echo "</tr>";
                                }
                            ?>
                        </tbody>
                    </table> 
                </div>
                <div class="modal-footer">
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <script>
        var customers=<?php echo json_encode($customers); ?>;
        function serve(index){
            $("#myModalLabel").html(customers[index][1]+" "+customers[index][2]+" <small>"+customers[index][0]+"</small>");
            $("#natid").val(customers[index][0]);

        }
    </script>
    <script>
        function filter(index){
            $("#myModalLabel1").html(customers[index][1]+" "+customers[index][2]+" <small>"+customers[index][0]+"</small>");
            var myclass="input.form-control.input-sm";
            $(myclass).val(customers[index][0]);
            $(myclass).trigger("input");
        }
    </script>
    <!-- /.modal -->
    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    $(document).ready(function() {
        $('#dataTables-history').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>