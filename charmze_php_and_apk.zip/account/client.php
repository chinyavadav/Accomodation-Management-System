<?php
    include("session.php");include("../includes/connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $accountno=mysqli_real_escape_string($conn,$_POST['txtaccountno']);
        $phoneno=mysqli_real_escape_string($conn,$_POST['txtphoneno']);
        $firstname=mysqli_real_escape_string($conn,$_POST['txtfirstname']);
        $surname=mysqli_real_escape_string($conn,$_POST['txtsurname']);
        $sex=mysqli_real_escape_string($conn,$_POST['cbosex']);
        $status=mysqli_real_escape_string($conn,$_POST['cbostatus']);
        $statement="UPDATE tblclients SET fldphoneno='$phoneno', fldfirstname='$firstname', fldsurname='$surname', fldsex='$sex',fldstatus='$status' WHERE fldaccountno='$accountno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        echo "<script>alert('Client record has been updated successfully!');window.location='client.php?acc=".base64_encode($accountno)."';</script>";
        exit();
    }
    if($_SERVER["REQUEST_METHOD"]=="GET" && isset($_GET['acc'])){
    	$accountno=base64_decode(mysqli_real_escape_string($conn,$_GET['acc']));
    	if(isset($_GET["remove"])){
    		$execute=mysqli_query($conn,"DELETE FROM tblclients WHERE fldaccountno='$accountno'") or deleteError($accountno);
    		echo "<script>alert('Record has been successfully deleted.');window.location='clients.php';</script>";
    		exit;

    	}
        
        $query=mysqli_query($conn,"SELECT * FROM tblclients WHERE fldaccountno='$accountno' LIMIT 0,1") or die(mysqli_error($conn));
        $record=mysqli_fetch_assoc($query);
        $phoneno=$record['fldphoneno'];
        $firstname=$record['fldfirstname'];
        $surname=$record['fldsurname'];
        $sex=$record['fldsex'];
        $status=$record['fldstatus'];
        $joined=$record['flddate'];        
    }else{
        header("Location: clients.php");
        exit;
    }
    function deleteError($accountno){
    	echo "<script>alert('Record could not be delete since it has attached dependancy record');window.location='client.php?acc=".base64_encode($accountno)."';</script>";
    	exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CHARMZE Accomodation System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
    <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <div id="wrapper">
        <?php include("header.html"); include("sidebar.html"); ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                    	<i class="fa fa-user"></i> <?php echo $firstname.' '.$surname; ?>
                    	<a href="client.php?acc=<?php echo base64_encode($accountno); ?>&remove" class='pull-right btn btn-danger'>
                    		<i class='fa fa-remove'></i> Delete
                    	</a>
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Registration Form
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form method="POST" action="">
                                        <div class="form-group col-lg-6">
                                            <label>Account No</label>
                                            <input class="form-control" readonly value="<?php echo $accountno; ?>" name="txtaccountno" required>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label>Phone No</label>
                                            <input class="form-control" type="text" name="txtphoneno" pattern="[0-9]{10}" value="<?php echo $phoneno; ?>" placeholder='0782777777' required>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label>First Name</label>
                                            <input class="form-control" value="<?php echo $firstname; ?>" placeholder="First Name" pattern="^[A-Za-z]{2,20}" name="txtfirstname" required>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label>Surname</label>
                                            <input class="form-control" value="<?php echo $surname; ?>" placeholder="Surname" pattern="^[A-Za-z]{2,20}" name="txtsurname">
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label>Sex</label>
                                            <select class="form-control" name="cbosex">
                                                <option id="Male">Male</option>
                                                <option id="Female">Female</option>                
                                            </select>
                                        </div>
                                        <script>
                                            $("#<?php echo $sex; ?>").attr("selected","");
                                        </script>
                                        <div class="form-group col-lg-6">
                                            <label>Status</label>
                                            <select class="form-control" name="cbostatus">
                                                <option id='Active'>Active</option>
                                                <option id='Disabled'>Disabled</option> 
                                            </select>
                                        </div>
                                        <script>
                                            $("#<?php echo $status; ?>").attr("selected","");
                                        </script>
                                        <div class="form-group col-lg-6">
                                            <label>Date Joined</label>
                                            <input class="form-control" type="date" name="dtjoined" readonly value="<?php echo $joined; ?>">
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <button class="btn btn-primary btn-block"><i class="fa fa-save"></i> Save</button>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
