<?php
    include("session.php");include("../includes/connection.php");include("send.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        
        $nationalid=mysqli_real_escape_string($conn,$_POST['txtnationalid']);
        $type=mysqli_real_escape_string($conn,$_POST['cbotype']);
        $message=mysqli_real_escape_string($conn,$_POST['txtmessage']);
        sms($_POST["txtcell"],$message);
        email($_POST["txtemail"],"ZNFPC NOTIFICATION",$message);
        echo "<script>alert('Message has been sent!');window.location='clients.php';</script>";
        exit;

    }

    if($_SERVER["REQUEST_METHOD"]=="GET" && isset($_GET['id'])){
        $nationalid=base64_decode(mysqli_real_escape_string($conn,$_GET['id']));
        $query=mysqli_query($conn,"SELECT * FROM tblclients WHERE fldnationalid='$nationalid' LIMIT 0,1") or die(mysqli_error($conn));
        $record=mysqli_fetch_assoc($query);
        $fname=$record['fldfirstname'];
        $lname=$record['fldlastname'];
        $cell=$record['fldcell'];
        $email=$record['fldemail'];
    }else{
        header("Location: clients.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CHARMZE Accomodation System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
    <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <div id="wrapper">
        <?php include("header.html"); include("sidebar.html"); ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><i class="fa fa-envelope"></i> Sending Message to <?php echo $fname[0].'. '.$lname.' <small>['."<a href='client.php?id=".base64_encode($nationalid)."'>".$nationalid.'</a>]</small>'; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Registration Form
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form method="POST" action="">
                                        <div class="form-group col-lg-12">
                                            <label>Message Type</label>
                                            <select name="cbotype" class="form-control">
                                                <option value="SMS &amp; Email">
                                                    <?php echo "SMS ($cell) &amp; Email ($email)"; ?>
                                                </option>
                                                <option value="SMS">
                                                    <?php echo "SMS ($cell)"; ?>
                                                </option>
                                                <option value="Email">
                                                    <?php echo "Email ($email)"; ?>
                                                </option>
                                            </select>
                                            <input type="hidden" name="txtnationalid" value="<?php echo $nationalid; ?>"/>
                                            <input type="hidden" name="txtcell" value="<?php echo $cell; ?>"/>
                                            <input type="hidden" name="txtemail" value="<?php echo $email; ?>"/>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label>Message</label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                                <textarea rows="2" class="form-control" placeholder="Message to Send" name="txtmessage" required></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <button class="btn btn-primary btn-block"><i class="fa fa-send"></i> Send</button>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
