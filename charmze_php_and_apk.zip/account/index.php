<?php
    include("../includes/connection.php");
    $statement_clients="SELECT COUNT(fldaccountno) FROM tblclients";
    $execute_clients=mysqli_query($conn,$statement_clients) or die(mysqli_error($conn));
    $clients=mysqli_fetch_assoc($execute_clients);
    $num_clients=$clients['COUNT(fldaccountno)'];

    $statement_apartments="SELECT COUNT(fldapartmentid) FROM tblapartments";
    $execute_apartments=mysqli_query($conn,$statement_apartments) or die(mysqli_error($conn));
    $apartments=mysqli_fetch_assoc($execute_apartments);

    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $message=$_POST["txtmessage"];
        $statement="SELECT fldemail,fldcell FROM tblclients";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $emails=[];
        $cells=[];
        $count=0;
        while($contact=mysqli_fetch_assoc($query)){
            $emails[$count]=$contact['fldemail'];
            $cells[$count]=$contact['fldcell'];
            $count++;
        }
        $cells=array_unique($cells);
        $emails=array_unique($emails);
        $cells=implode(",",$cells);
        $emails=implode(",",$emails);
        email($emails,"ZNFPC NOTIFICATION",$message);
        sms($cells,$message);
        echo "<script>alert('Messages successfully sent!');</script>";

    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CHARMZE Accomodation System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">
    	<?php include("header.html");include("sidebar.html"); ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
 <!-- /.row -->
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-users fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $clients['COUNT(fldaccountno)']; ?></div>
                                <div>Clients</div>
                            </div>
                        </div>
                    </div>
                    <a href="clients.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="panel panel-yellow">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-home fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $apartments['COUNT(fldapartmentid)']; ?></div>
                                <div>Apartments</div>
                            </div>
                        </div>
                    </div>
                    <a href="apartments.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.row -->
            <div class="row">
                <div class="col-lg-8"></div>
                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bell fa-fw"></i> Notifications Panel
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="list-group">
                            <?php
                                $execute_backup=mysqli_query($conn,"SELECT MAX(fldfilename) FROM tblbackups") or die(mysqli_error($conn));
                                if(mysqli_num_rows($execute_backup)>0){
                                    $timestamp=substr_replace(mysqli_fetch_assoc($execute_backup)["MAX(fldfilename)"],"",-3);
                                    $diff=time()-(int) $timestamp;
                                    $days=$diff/(3600*24);
                                    $minutes=(time()-(int)$timestamp)/100;
                                        if($minutes>1440){
                                            $time=(int)($minutes/1440)." Days ago";
                                        }elseif($minutes>60){
                                          $time=(int)($minutes/60)." Hours ago";
                                        }elseif($minutes>1){
                                          $time=(int)$minutes." Minutes ago ";
                                        }else{
                                          $time="Just Now";
                                        }
                                    if($days>=1){
                                        ?>                                    
                                            <a href="backup.php" class="list-group-item">
                                                <i class="fa fa-database fa-fw"></i> Backup Overdue
                                                <span class="pull-right text-muted small"><em><?php echo "by ".round($days,0)." Days"; ?></em>
                                                </span>
                                            </a>
                                        <?php
                                    }else{
                                        ?>
                                            <a href="backup.php" class="list-group-item">
                                                <i class="fa fa-database fa-fw"></i> Last Backup
                                                <span class="pull-right text-muted small"><em><?php echo $time; ?></em>
                                                </span>
                                            </a>
                                        <?php                                    
                                    }
                                }
                            ?>
                                     </div>
                        </div>
                        <!-- /.panel-footer -->
                    </div>
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
