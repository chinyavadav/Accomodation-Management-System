<?php
  include("session.php");include("../includes/connection.php");
  if($_SERVER["REQUEST_METHOD"]=="POST"){    
    $name=$_POST["txtname"];
    $type=$_POST["cbotype"];
    $magnitude=$_POST["txtmagnitude"];
    $duration=$_POST["txtmagnitude"].' '.$_POST["cbounits"];
    $price=$_POST["txtprice"];
    $date=date('Y-m-d H:i:s');
    $query="INSERT INTO tblmethods VALUES('$name','$type','$duration','$price','$userEmail','$date')";
    $execute=mysqli_query($conn,$query) or die(duplicate());
    echo "<script>alert('Method has been successfully added!');window.location='methods.php';</script>";
  }
  function duplicate(){
    echo "<script>alert('Method already exists!');window.location='methods.php';</script>";
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CHARMZE Accomodation System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">
        <?php include("header.html"); include("sidebar.html"); ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><i class="fa fa-medkit"></i> Add Family Planning Method</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Details
                        </div>
                        <div class="panel-body">
                        <form method="post" action="">
                            <div class="form-group col-lg-6">
                                <label for="txtname">Method Name</label>
                                <input type="text" name="txtname" class="form-control" required maxlength="50" placeholder="Method Name"/>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="cbotype">Type</label>
                                <select name="cbotype" class="form-control">
                                    <option>Oral</option>
                                    <option>Injection</option>
                                    <option>Insertion</option>
                                    <option>Implant</option>
                                    <option>Procedure</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="txtname">Duration</label>
                                <div class="input-group">
                                    <input type="number" name="txtmagnitude" class="form-control" required min="0" />
                                    <span class="input-group-addon">
                                        <select name="cbounits" style="background-color:#eee;border-color:#eee;">
                                            <option>Months</option>
                                            <option>Years</option>
                                            <option>Days</option>
                                        </select>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group col-lg-6">
                                <label for="txtprice">Price</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-usd"></i></span><input type="number" name="txtprice" class="form-control" required min="0"/>
                                </div>
                            </div>
                            <div class="form-group col-lg-6"></div>
                            <div class="form-group col-lg-12">
                                <button type="submit" name="cbosave" class="btn btn-primary btn-block"><i class="fa fa-save"></i> Save</button>
                            </div>
                        </form>
                        </div>
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
