<?php
    include("session.php");include("../includes/connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $apartmentid=mysqli_real_escape_string($conn,$_POST['txtapartmentid']);
        $type=mysqli_real_escape_string($conn,$_POST['cbotype']);
        $price=mysqli_real_escape_string($conn,$_POST['txtprice']);
        $duration=$_POST["txtmagnitude"].' '.$_POST["cbounits"];

        $statement="UPDATE tblapartments SET fldtype='$type',fldprice='$price',fldduration='$duration' WHERE fldapartmentid='$apartmentid'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        echo "<script>alert('apartment has been updated successfully!');window.location='apartment.php?id=".base64_encode($apartmentid)."';</script>";
        exit;

    }
    $districts=['Beitbridge','Bikita','Bindura','Binga','Bubi','Buhera','Bulawayo','Bulilima','Centenary','Chegutu','Chikomba','Chimanimani','Chinhoyi','Chipinge','Chiredzi','Chirumhanzu','Chivi','Gokwe North','Gokwe South','Goromonzi','Guruve','Gutu','Gwanda','Gweru','Harare','Hurungwe','Hwange','Insiza','Kariba','Kwekwe','Lupane','Makonde','Makoni','Mangwe','Marondera','Masvingo','Matobo','Mazowe','Mberengwa','Mbire','Mhondoro-Ngezi','Mount Darwin','Mudzi','Murehwa','Mutare','Mutasa','Mutoko','Muzarabani','Mwenezi','Nkayi','Nyanga','Rushinga','Sanyati','Seke','Shamva','Shurugwi','Tsholotsho','Umguza','UMP (Uzumba-Maramba-Pfungwe)','Umzingwane','Wedza (Hwedza)','Zaka','Zvimba','Zvishavane'];
    if($_SERVER["REQUEST_METHOD"]=="GET" && isset($_GET['id'])){
        $apartmentid=base64_decode(mysqli_real_escape_string($conn,$_GET['id']));
        $query=mysqli_query($conn,"SELECT * FROM tblapartments WHERE fldapartmentid='$apartmentid' LIMIT 0,1") or die(mysqli_error($conn));
        $record=mysqli_fetch_assoc($query);
    }else{
        header("Location: apartments.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CHARMZE Accomodation System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
    <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <link href="../styles/img/favicon.png" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <div id="wrapper">
        <?php include("header.html"); include("sidebar.html"); ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><i class="fa fa-home"></i> <?php echo $apartmentid; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Registration Form
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form apartment="POST" action="">
                                        <div class="form-group col-lg-6">
                                            <label>Apartment ID</label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-home"></i></span>
                                                <input readonly class="form-control" type="text" value="<?php echo $record['fldapartmentid']; ?>" name="txtapartmentid">
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label>Landlord Account No</label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                <input readonly class="form-control" type="text" value="<?php echo $record['fldlandlord']; ?>" name="txtlandlord">
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label>Address</label>
                                            <textarea rows='1' class="form-control" name="txtaddress"><?php echo $record['fldaddress']; ?></textarea>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label>Township/Suburb</label>
                                            <input class="form-control" type="text" value="<?php echo $record['fldtownship']; ?>" name="txttownship" list='townships'>
                                            <datalist id='townships'>
                                                <option>Central Business District</option>
                                                <option>Senga</option>
                                                <option>Nehosho</option>
                                                <option>KMP</option>
                                                <option>Mkoba</option>
                                                <option>Ivene</option>
                                            </datalist>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <label>District</label>
                                            <select name="txtdistrict" class="form-control" id="district">
                                                <?php
                                                    foreach ($districts as $district) {
                                                        echo "<option id='$district'>$district</option>";
                                                    }
                                                ?>
                                            </select>
                                            <script>
                                                $("#<?php echo $record['flddistrict']; ?>").attr("selected","");
                                            </script>
                                        </div>

                                        <div class="form-group col-lg-12">
                                            <button class="btn btn-primary btn-block"><i class="fa fa-save"></i> Update</button>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>
     <script>
        $("#<?php echo $type; ?>").attr("selected","");
         $("#<?php echo $duration[1]; ?>").attr("selected","");
    </script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
