DROP TABLE tblclients;

CREATE TABLE `tblclients` (
  `fldnationalid` varchar(15) NOT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldmiddlename` varchar(20) DEFAULT NULL,
  `fldsex` varchar(6) DEFAULT NULL,
  `flddob` varchar(10) DEFAULT NULL,
  `fldhivStatus` varchar(20) NOT NULL DEFAULT 'Negative',
  `fldcell` varchar(14) DEFAULT NULL,
  `fldemail` varchar(64) DEFAULT NULL,
  `fldaddress` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`fldnationalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblclientsVALUES("29-308399E04","Moyo","Shamaine","","Female","1997-05-16","Negative","263718631284","smugwenhi@gmail.com","21 Development House 7th Street, Gweru");
INSERT INTO tblclientsVALUES("29-308399E05","Ndebele","Patience","","Female","1995-01-04","Positive","263782135087","chinyavadav@gmail.com","21 Mkoba 12, Gweru");



DROP TABLE tblbackups;

CREATE TABLE `tblbackups` (
  `fldbackupid` int(11) NOT NULL AUTO_INCREMENT,
  `flddatetime` varchar(20) DEFAULT NULL,
  `flddoneby` varchar(64) DEFAULT NULL,
  `fldfilename` varchar(20) NOT NULL,
  PRIMARY KEY (`fldbackupid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO tblbackupsVALUES("9","2018-04-27 20:26:47","smugwenhi@gmail.com","1524853607.sql");
INSERT INTO tblbackupsVALUES("10","2018-04-27 20:26:51","smugwenhi@gmail.com","1524853611.sql");
INSERT INTO tblbackupsVALUES("11","2018-04-27 20:29:42","smugwenhi@gmail.com","1524853782.sql");
INSERT INTO tblbackupsVALUES("12","2018-04-27 20:48:48","smugwenhi@gmail.com","1524854928.sql");
INSERT INTO tblbackupsVALUES("13","2018-04-28 11:05:23","smugwenhi@gmail.com","1524906323.sql");
INSERT INTO tblbackupsVALUES("14","2018-05-11 09:36:55","smugwenhi@gmail.com","1526024215.sql");
INSERT INTO tblbackupsVALUES("15","2018-05-11 09:37:10","smugwenhi@gmail.com","1526024230.sql");
INSERT INTO tblbackupsVALUES("16","2018-05-11 09:37:28","smugwenhi@gmail.com","1526024248.sql");
INSERT INTO tblbackupsVALUES("17","2018-05-11 09:37:33","smugwenhi@gmail.com","1526024253.sql");
INSERT INTO tblbackupsVALUES("18","2018-05-11 09:37:45","smugwenhi@gmail.com","1526024265.sql");
INSERT INTO tblbackupsVALUES("19","2018-05-11 09:38:14","smugwenhi@gmail.com","1526024294.sql");
INSERT INTO tblbackupsVALUES("20","2018-05-11 09:39:12","smugwenhi@gmail.com","1526024352.sql");



DROP TABLE tblclients;

CREATE TABLE `tblclients` (
  `fldnationalid` varchar(15) NOT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldmiddlename` varchar(20) DEFAULT NULL,
  `fldsex` varchar(6) DEFAULT NULL,
  `flddob` varchar(10) DEFAULT NULL,
  `fldhivStatus` varchar(20) NOT NULL DEFAULT 'Negative',
  `fldcell` varchar(14) DEFAULT NULL,
  `fldemail` varchar(64) DEFAULT NULL,
  `fldaddress` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`fldnationalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblclientsVALUES("29-308399E04","Moyo","Shamaine","","Female","1997-05-16","Negative","263718631284","smugwenhi@gmail.com","21 Development House 7th Street, Gweru");
INSERT INTO tblclientsVALUES("29-308399E05","Ndebele","Patience","","Female","1995-01-04","Positive","263782135087","chinyavadav@gmail.com","21 Mkoba 12, Gweru");



DROP TABLE tbllogs;

CREATE TABLE `tbllogs` (
  `flddate` varchar(10) NOT NULL,
  PRIMARY KEY (`flddate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tbllogsVALUES("2018-05-10");



DROP TABLE tblmethods;

CREATE TABLE `tblmethods` (
  `fldmethod_name` varchar(100) NOT NULL,
  `fldtype` varchar(20) DEFAULT NULL,
  `fldduration` varchar(20) DEFAULT NULL,
  `fldprice` float DEFAULT NULL,
  `fldcreatedby` varchar(64) DEFAULT NULL,
  `flddate` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fldmethod_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblmethodsVALUES("COC","Oral","2 Days","2","smugwenhi@gmail.com","2018-04-02 09:23:00");
INSERT INTO tblmethodsVALUES("Jadel","Oral","0 Months","1","smugwenhi@gmail.com","2018-05-09 21:23:55");
INSERT INTO tblmethodsVALUES("POP","Oral","3 Years","1","smugwenhi@gmail.com","2018-04-02 11:11:12");



DROP TABLE tblpayments;

CREATE TABLE `tblpayments` (
  `fldserviceid` int(11) NOT NULL,
  `fldnationalid` varchar(20) DEFAULT NULL,
  `fldpaymentmethod` varchar(20) DEFAULT NULL,
  `fldamount` double DEFAULT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fldserviceid`),
  KEY `fldnationalid` (`fldnationalid`),
  CONSTRAINT `tblpayments_ibfk_1` FOREIGN KEY (`fldnationalid`) REFERENCES `tblclients` (`fldnationalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblpaymentsVALUES("30","29-308399E04","Cash","2","2018-04-28 10:54:09");
INSERT INTO tblpaymentsVALUES("32","29-308399E05","Cash","2","2018-04-28 10:54:58");
INSERT INTO tblpaymentsVALUES("33","29-308399E04","Bank Card (Swipe)","1","2018-05-09 21:26:06");
INSERT INTO tblpaymentsVALUES("34","29-308399E04","Cash","1","2018-05-10 21:03:00");



DROP TABLE tblservices;

CREATE TABLE `tblservices` (
  `fldserviceid` int(11) NOT NULL AUTO_INCREMENT,
  `fldnationalid` varchar(50) NOT NULL,
  `fldbp` varchar(20) DEFAULT NULL,
  `fldweight` float NOT NULL,
  `fldsugarlevel` varchar(20) DEFAULT NULL,
  `fldparity` int(11) NOT NULL,
  `fldcurrentmedication` varchar(100) DEFAULT NULL,
  `fldmethod` varchar(100) DEFAULT NULL,
  `fldnextdate` varchar(10) DEFAULT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fldserviceid`),
  KEY `fldnationalid` (`fldnationalid`),
  KEY `fldmethod` (`fldmethod`),
  CONSTRAINT `tblservices_ibfk_1` FOREIGN KEY (`fldnationalid`) REFERENCES `tblclients` (`fldnationalid`),
  CONSTRAINT `tblservices_ibfk_2` FOREIGN KEY (`fldmethod`) REFERENCES `tblmethods` (`fldmethod_name`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO tblservicesVALUES("22","29-308399E04","23","23","23","2","N/A","POP","2018-05-11","2018-05-11 10:00:33");
INSERT INTO tblservicesVALUES("23","29-308399E04","23","23","23","2","N/A","POP","2018-07-27","2018-04-28 10:02:28");
INSERT INTO tblservicesVALUES("24","29-308399E04","23","23","23","2","N/A","POP","2021-04-27","2018-04-28 10:03:04");
INSERT INTO tblservicesVALUES("25","29-308399E04","23","23","23","2","N/A","POP","2021-04-27","2018-04-28 10:04:59");
INSERT INTO tblservicesVALUES("26","29-308399E04","23","23","23","2","N/A","POP","2021-04-27","2018-04-28 10:05:59");
INSERT INTO tblservicesVALUES("28","29-308399E04","12","12","12","12","N/A","COC","2018-04-30","2018-04-28 10:23:10");
INSERT INTO tblservicesVALUES("29","29-308399E04","12","12","12","12","N/A","COC","2018-04-30","2018-04-28 10:23:40");
INSERT INTO tblservicesVALUES("30","29-308399E04","12","12","12","12","N/A","COC","2018-04-30","2018-04-28 10:23:40");
INSERT INTO tblservicesVALUES("32","29-308399E05","2","2","2","3","N/A","COC","2018-04-30","2018-04-28 10:54:53");
INSERT INTO tblservicesVALUES("33","29-308399E04","1","1","12.2","1","                                                
                            ","COC","2018-05-13","2018-05-11 09:16:54");



DROP TABLE tblusers;

CREATE TABLE `tblusers` (
  `fldemail` varchar(64) NOT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `flddepartment` varchar(50) NOT NULL,
  `fldaccesslevel` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`fldemail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblusersVALUES("smugwenhi@gmail.com","Sam","Mugwenhi","ICT","Administrator","5f4dcc3b5aa765d61d8327deb882cf99");



