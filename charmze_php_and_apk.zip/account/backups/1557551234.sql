DROP TABLE tblclients;

CREATE TABLE `tblclients` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldphoneno` varchar(10) NOT NULL,
  `fldfirstnames` varchar(50) DEFAULT NULL,
  `fldsurname` varchar(30) DEFAULT NULL,
  `fldsex` varchar(10) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  `flddate` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`fldaccountno`),
  UNIQUE KEY `fldphoneno` (`fldphoneno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblclientsVALUES("C192345N","0782135087","Victor","Chinyavada","Male","Active","5f4dcc3b5aa765d61d8327deb882cf99","2019-05-08");
INSERT INTO tblclientsVALUES("C195836F","0712923278","Peter","Chinyavada","Male","Active","5f4dcc3b5aa765d61d8327deb882cf99","2019-05-09");



DROP TABLE tblapartments;

CREATE TABLE `tblapartments` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldlandlord` varchar(8) DEFAULT NULL,
  `fldaddress` varchar(200) DEFAULT NULL,
  `fldtownship` varchar(50) DEFAULT NULL,
  `fldtown` varchar(50) DEFAULT NULL,
  `fldlat` varchar(20) DEFAULT NULL,
  `fldlng` varchar(20) DEFAULT NULL,
  `fldapartmenttype` varchar(20) DEFAULT NULL,
  `fldrooms` int(11) DEFAULT NULL,
  `fldbedrooms` int(11) DEFAULT NULL,
  `fldkitchen` int(11) DEFAULT NULL,
  `fldbathroom` int(11) DEFAULT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldternant` varchar(8) DEFAULT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcostrange` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`fldapartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE tblbackups;

CREATE TABLE `tblbackups` (
  `fldbackupid` int(11) NOT NULL AUTO_INCREMENT,
  `flddatetime` varchar(20) DEFAULT NULL,
  `flddoneby` varchar(64) DEFAULT NULL,
  `fldfilename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`fldbackupid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE tblbookings;

CREATE TABLE `tblbookings` (
  `fldapartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `fldaccountno` varchar(8) NOT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fldapartmentid`,`fldaccountno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE tblclients;

CREATE TABLE `tblclients` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldphoneno` varchar(10) NOT NULL,
  `fldfirstnames` varchar(50) DEFAULT NULL,
  `fldsurname` varchar(30) DEFAULT NULL,
  `fldsex` varchar(10) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  `flddate` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`fldaccountno`),
  UNIQUE KEY `fldphoneno` (`fldphoneno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblclientsVALUES("C192345N","0782135087","Victor","Chinyavada","Male","Active","5f4dcc3b5aa765d61d8327deb882cf99","2019-05-08");
INSERT INTO tblclientsVALUES("C195836F","0712923278","Peter","Chinyavada","Male","Active","5f4dcc3b5aa765d61d8327deb882cf99","2019-05-09");



DROP TABLE tblprofiles;

CREATE TABLE `tblprofiles` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldmaritalstatus` varchar(20) DEFAULT NULL,
  `fldcohabitors` int(11) DEFAULT NULL,
  `fldother` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`fldaccountno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE tblusers;

CREATE TABLE `tblusers` (
  `fldemail` varchar(64) NOT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`fldemail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblusersVALUES("admin@charmze.co.zw","John","Moyo","5f4dcc3b5aa765d61d8327deb882cf99");



