DROP TABLE tblclients;

CREATE TABLE `tblclients` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldphoneno` varchar(10) NOT NULL,
  `fldfirstname` varchar(50) DEFAULT NULL,
  `fldsurname` varchar(30) DEFAULT NULL,
  `fldsex` varchar(10) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  `flddate` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`fldaccountno`),
  UNIQUE KEY `fldphoneno` (`fldphoneno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblclientsVALUES("C192345N","0782135087","Victor","Chinyavada","Male","Active","5f4dcc3b5aa765d61d8327deb882cf99","2019-05-08");



DROP TABLE tblapartments;

CREATE TABLE `tblapartments` (
  `fldapartmentid` varchar(8) NOT NULL,
  `fldlandlord` varchar(8) DEFAULT NULL,
  `fldaddress` varchar(200) DEFAULT NULL,
  `fldtownship` varchar(50) DEFAULT NULL,
  `flddistrict` varchar(50) DEFAULT NULL,
  `fldlat` varchar(20) DEFAULT NULL,
  `fldlng` varchar(20) DEFAULT NULL,
  `fldapartmenttype` varchar(20) DEFAULT NULL,
  `fldrooms` int(11) DEFAULT NULL,
  `fldbedrooms` int(11) DEFAULT NULL,
  `fldbathrooms` int(11) DEFAULT NULL,
  `fldkitchens` int(11) DEFAULT NULL,
  `fldlounges` int(11) NOT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldternant` varchar(8) DEFAULT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcostrange` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`fldapartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblapartmentsVALUES("A193610C","C192345N","12 Development House","Town","Gweru","","","Shared","6","2","1","1","1","","Vacant","","2019-05-13 11:55:55","$500-$999");



DROP TABLE tblbackups;

CREATE TABLE `tblbackups` (
  `fldbackupid` int(11) NOT NULL AUTO_INCREMENT,
  `flddatetime` varchar(20) DEFAULT NULL,
  `flddoneby` varchar(64) DEFAULT NULL,
  `fldfilename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`fldbackupid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO tblbackupsVALUES("1","2019-05-11 07:07:14","admin@charmze.co.zw","1557551234.sql");
INSERT INTO tblbackupsVALUES("2","2019-05-12 18:55:33","admin@charmze.co.zw","1557680133.sql");



DROP TABLE tblbookings;

CREATE TABLE `tblbookings` (
  `fldapartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `fldaccountno` varchar(8) NOT NULL,
  `flddatetime` varchar(20) DEFAULT NULL,
  `fldcomment` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fldapartmentid`,`fldaccountno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE tblclients;

CREATE TABLE `tblclients` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldphoneno` varchar(10) NOT NULL,
  `fldfirstname` varchar(50) DEFAULT NULL,
  `fldsurname` varchar(30) DEFAULT NULL,
  `fldsex` varchar(10) DEFAULT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  `flddate` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`fldaccountno`),
  UNIQUE KEY `fldphoneno` (`fldphoneno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblclientsVALUES("C192345N","0782135087","Victor","Chinyavada","Male","Active","5f4dcc3b5aa765d61d8327deb882cf99","2019-05-08");



DROP TABLE tblprofiles;

CREATE TABLE `tblprofiles` (
  `fldaccountno` varchar(8) NOT NULL,
  `fldmaritalstatus` varchar(20) DEFAULT NULL,
  `fldcohabitors` int(11) DEFAULT NULL,
  `fldother` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`fldaccountno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE tblusers;

CREATE TABLE `tblusers` (
  `fldemail` varchar(64) NOT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`fldemail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tblusersVALUES("admin@charmze.co.zw","John","Moyo","5f4dcc3b5aa765d61d8327deb882cf99");
INSERT INTO tblusersVALUES("sales@charmze.co.zw","Bill","Gates","5f4dcc3b5aa765d61d8327deb882cf99");



