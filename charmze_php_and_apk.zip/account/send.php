<?php
	function email($email,$subject,$message){

		$to = $email;
		$subject = $subject;
		$txt = $message;
		$headers = "From: smugwenhi@gmail.com" . "\r\n";
		//"CC: somebodyelse@example.com";

		mail($to,$subject,$txt,$headers);

	}
	function sms($phones,$message){
    	error_reporting(0);
    	$username = 'chinyavadav';
	    $token = '20eff79d4b271fef918efd04c098b045';
	    $bulksms_ws = 'http://portal.bulksmsweb.com/index.php?app=ws';
	    $ws_str = $bulksms_ws . '&u=' . $username . '&h=' . $token . '&op=pv';
    	$ws_str .= '&to=' . urlencode($phones) . '&msg='.urlencode($message);
    	$ws_response = @file_get_contents($ws_str);
    	return $ws_response;
	}
?>